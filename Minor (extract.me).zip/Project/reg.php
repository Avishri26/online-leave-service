<?php
	session_start();
	$host = "localhost";
	$user = "root";
	$password = "";
	$db = "college";
	$con  = mysql_connect($host,$user,$password);
	mysql_select_db($db,$con);
	
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$emp_id = $_POST['emp_id'];
	$email = $_POST['email'];
	$department = $_POST['department'];
	$dob = $_POST['date'];
	$gender = $_POST['gender'];
	$mobile_no = $_POST['mobile_no'];
	$password = $_POST['pwd1'];
	$password2 = $_POST['pwd2'];
		
	$sql = "insert into employees(First_name,Last_name,Employee_id,Email,Department,DOB,Gender,Mobile_no,Password) values ('$fname','$lname','$emp_id','$email','$department','$dob','$gender','$mobile_no','$password')";
	if(mysql_query($sql)){
		
		echo "Employee details entered successfully";
		header("Refresh:3;url=login.html");
	}
	else
	{
		echo "problem occured";
		header("Refresh:3;url=reg.html");
		
	}	
	

?>