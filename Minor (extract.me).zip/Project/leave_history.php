<?php
	session_start();
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "college";
	$con = mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	$id = $_SESSION['username'];
?>
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "welcome.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
<title></title>
<style>

th, td {
	border: 1px solid #ddd;
  text-align: left;
  padding: 5px;
  text-align: left;
}
table {
  border: 1px solid #ddd;
  text-align: left;
  width: 70%;
}
</style>
</head>
<body>

<header class="img">

<img src = "4.png" height = 100px align =left>
<h1>Online Leave Management System</h1>
</header>

<nav>
<ul>
  <li><a href="welcome.php">Dashboard</a></li>
  <li><a href="update_profile.php" >Update Profile</a></li>
  <li><a href="change_password.html">Change Password</a></li>
  <li><a href="apply_for_leave.html">Apply for leave</a></li>
  <li><a href="leave_history.php" class="active">Leave history</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>

<div class="pageleavehistory" style='overflow:scroll;overflow-x:hidden;overflow-y:scroll;'> 
	<center>
	<h1>Leave History</h1><hr style="width:80%">
	<table >
	<tr>
		<th>Employee_id</th>
		<th>Start_date</th>
		<th>End_date</th>
		<th>Type</th>
		<th>Description</th>
		<th>Status</th>
	</tr>
	<?php
		$history = mysql_query("Select * from leaves where Employee_id = '$id' ");
		
		while($result = mysql_fetch_array($history)){
			
			echo "<tr;>";
				echo "<td >".$result['Employee_id']."</td>";
				echo "<td>".$result['Start_date']."</td>";
				echo "<td>".$result['End_date']."</td>";
				echo "<td>".$result['Type']."</td>";
				echo "<td >".$result['Description']."</td>";
				echo "<td>".$result['Status']."</td>";
				
			echo "</tr>";
			
			
		}
	?>
	</table> 
	</center>
</div>

</body>
</html>