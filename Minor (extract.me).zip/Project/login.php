<?php
	session_start();
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	if(!isset($_POST['Login'])){
		$email = $_POST['email'];
		$password = $_POST['password'];
		if($email == 'admin1620@gmail.com' && $password == 'AdminHOD@1620'){
			$_SESSION["username"] = 'admin1620';
			header("Location: admin/welcome_a.php");
		}
		else{
			$login = "SELECT Employee_id,Email,Password FROM employees WHERE Email = '$email' AND Password = '$password' ";
			$result = mysql_query($login);
			$row = mysql_fetch_array($result);
			$_SESSION["username"] = $row['Employee_id'];
			if(mysql_num_rows($result) > 0){
				header("Location:welcome.php");
			}
			else{
				echo "Username or password incorrect";
				header("Refresh:3;url=login.html");
			}
		}
	}
	else{
		
		echo "Enter email and Password";
		header("Refresh :3;url:login.html");
	}
?>