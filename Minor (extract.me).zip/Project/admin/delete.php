<?php
	session_start();
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "college";
	$con = mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	$id = $_SESSION['username']; 
	$name = $_POST['emp'];
	
	$delete = mysql_query("Delete from employees where Employee_id = '$name'");
	
	if(mysql_affected_rows($con) == 1){
			$delete_leaves = mysql_query("Delete from leaves where Employee_id = '$name'");
			if(mysql_affected_rows($con) == 1){
				echo "Employee ".$name." deleted successfully";
				$leave = mysql_query("Update employees SET Leaves_taken = '0' where Employee_id = '$name'");
				
				header("Refresh:6;url=welcome_a.php");
			}
			else{
				echo "Employee ".$name." deleted successfully"."<br>";
				
				header("Refresh:3;url=delete_employee.php");	
			}
	}
	else{
			echo "Error Occured ee";
			header("Refresh:3;url=delete_employee.php");
	}
	
	
	

?>