<?php
	session_start();
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "college";
	$con = mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	$id = $_SESSION['username']; 
	
		$i = 0;
		$row = mysql_query("Select *from leaves where Status = 'Pending'");
		while(mysql_fetch_array($row)){
			//name attribute in html is an arrray
			$status = $_POST['status'][$i];
			//First row Employee id is taken in member variable
			$member = $row['Employee_id'];
			//Now updating the first value of array status to 1st employee in $row variable(value assigned to member variable) 
			$update = mysql_query("Update leaves SET Status = '$status' where  Employee_id = '$member'");
			if(mysql_affected_rows($con) == 1){
						$i++;
			}
			else{ 
				
				
				$done = "false";
				break;
			}
			
		}
		if($done == false){
				echo "problem occured";
		}
		else{
				echo "Done";
				header("Refresh : 3;url=leave_request.php");
		}
		
?>