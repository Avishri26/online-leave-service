<?php
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	session_start();
	$id = $_SESSION['username'];
	
	$value =  $_SESSION['id1'];
	$sql = mysql_query("Update leaves SET Status = 'Decline' where Leave_id = '$value'");
	if(mysql_affected_rows($con)==1){
			echo "Declined";
			
			header("Refresh:3;url=leave_request1.php");
	}
	else{
			echo "Error Occured";
			
			header("Refresh:3;url=leave_request1.php");
	}
	unset($_SESSION["id1"]);
			
?>