<?php
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	session_start();
	$id = $_SESSION['username'];
	
	$value =  $_SESSION['id1'];
		$value1 =  $_SESSION['id2'];
	
	
	
	$sql = mysql_query("Update leaves SET Status = 'Accept' where Leave_id = '$value'");
	if(mysql_affected_rows($con)==1){
			echo "Accepted";
			$leave = mysql_query("Select Leaves_taken from employees where Employee_id = '$value1'");
			$row = mysql_fetch_array($leave);
			$count = $row['Leaves_taken'];
			$count = $count + 1;
			$set = mysql_query("Update employees SET leaves_taken = '$count'");
			if(!(mysql_affected_rows($con) == 1)){
				echo "error occured";	
			}
			
			header("Refresh:3;url=leave_request1.php");
	}
	else{
			echo "Error Occured";
			
			header("Refresh:3;url=leave_request1.php");
	}
	unset($_SESSION["id1"]);
			
?>