<?php 
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	session_start();
	$id = $_SESSION['username'];
	$result = mysql_query("Select * from employees where Employee_id= '$id' ");
	$row = mysql_fetch_array($result);
	$i = 0;
?>

<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "welcome.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
<title></title>
</head>
<style>

th, td {
	border: 1px solid #ddd;
  text-align: left;
  padding: 5px;
  text-align: left;
}
table {
  border: 1px solid #ddd;
  text-align: left;
  width: 50%;
}
</style>
<body>

<header class="img">

<img src = "4.png" height = 100px align =left>
<h1>Online Leave Management System</h1>
</header>

<nav>
<ul>
 <li><a href="welcome_a.php">Dashboard</a></li>
  <li><a href="delete_employee.php" >Delete Employees</a></li>
  <li><a href="leave_request1.html"class="active">Leave Request</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>

<div style = "overflow:scroll;overflow-x:hidden;overflow-y:scroll" class="pageleaverequest"> 
	<form method = "POST" action="respond.php">
	<center><h1>Your Employees</h1><hr style="width:80%">
	<table >
	<tr>
		<th>Employee_id</th>
		<th>Start_date</th>
		<th>End_date</th>
		<th>Type</th>
		<th>Description</th>
		<th>Status</th>
		
		
	</tr>
	<?php
		$history = mysql_query("Select * from leaves where Status = 'Pending' ");
		
		while($result = mysql_fetch_array($history)){
			
			echo "<tr>";
				echo "<td >".$result['Employee_id']."</td>";
				echo "<td>".$result['Start_date']."</td>";
				echo "<td>".$result['End_date']."</td>";
				echo "<td>".$result['Type']."</td>";
				echo "<td >".$result['Description']."</td>";
				$_SESSION['id1'] = $result['Leave_id'];
				$_SESSION['id2'] = $result['Employee_id'];
				?>
				<td ><a href="accept.php">Accept</a>
				<a href="decline.php">Decline</a></td>
				<?php
				
				
				echo "</tr>";	
				
		
		}
		?>
	
		
	
	</table> <br>
	

	</center>
</form>


</div>

</body>
</html>