
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "welcome.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
<title></title>
</head>
<body>
<style>

th, td {
	border: 1px solid #ddd;
  text-align: left;
  padding: 5px;
  text-align: left;
}
table {
  border: 1px solid #ddd;
  text-align: left;
  width: 50%;
}
</style>
<?php 
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	session_start();
	$id = $_SESSION['username'];
	$result = mysql_query("Select * from employees where Employee_id= '$id' ");
	$row = mysql_fetch_array($result);
?>
<header class="img">

<img src = "4.png" height = 100px align =left>
<h1>Online Leave Management System</h1>
</header>

<nav>
<ul>
  <li><a href="welcome_a.php">Dashboard</a></li>
  <li><a href="delete_employee.php" class="active">Delete Employees</a></li>
  <li><a href="leave_request1.php">Leave Request</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>

<div class="pagewelcome" style = "overflow:scroll;overflow-x:hidden;overflow-y:scroll"> 
<form method = "POST" action="delete.php">
	<center><h1>Your Employees</h1><hr style="width:80%">
	<table >
	<tr>
		<th></th>
		<th>Employee_id</th>
		<th>First_name</th>
		<th>Last_name</th>
		<th>Email</th>
		
		
		
		<th>Leave_taken</th>
	</tr>
	<?php
		$history = mysql_query("Select * from employees ");
		
		while($result = mysql_fetch_array($history)){
			if(!($result['Employee_id'] == 'admin1620')){
				echo "<tr;>";
				?>
				<td><input style="width:20px" type="radio" name="emp" value ="<?php echo $result['Employee_id']?>"</td>
				<?php
					echo "<td >".$result['Employee_id']."</td>";
					echo "<td>".$result['First_name']."</td>";
					echo "<td>".$result['Last_name']."</td>";
					echo "<td>".$result['Email']."</td>";
					echo "<td>".$result['Leaves_taken']."</td>";
				echo "</tr>";
			}
		}
	?>
			
	
	</table> 
	<button>DELETE</button>

	</center>
</form>
</div>

</body>
</html>