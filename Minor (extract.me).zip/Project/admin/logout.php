<?php
	session_start();
	unset($_SESSION["username"]);
	session_destroy();
	header("Refresh:0;url=../login.html");
?>