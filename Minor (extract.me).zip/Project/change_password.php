<?php
	session_start();
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "college";
	$con = mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	$id = $_SESSION['username'];
	
		$pass = $_POST['password'];
		
		$change = mysql_query("UPDATE employees SET Password = '$pass' where Employee_id = '$id'");
		if(mysql_affected_rows($con) == 1){
				echo "Password changed successfuly";
				header("Refresh:3;url=welcome.php");
		}
		else {
			echo "Error Occured"."<br>";
			echo "Do not enter same password again";
			header("Refresh:3;url=change_password.html");
		}
			
	
?>