
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "welcome.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
<title></title>
</head>
<body>
<?php 
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	session_start();
	$id = $_SESSION['username'];
	$result = mysql_query("Select * from employees where Employee_id= '$id' ");
	$row = mysql_fetch_array($result);
?>
<header class="img">

<img src = "4.png" height = 100px align =left>
<h1>Online Leave Management System</h1>
</header>

<nav>
<ul>
  <li><a href="welcome.php"class="active">Dashboard</a></li>
  <li><a href="update_profile.php" >Update Profile</a></li>
  <li><a href="change_password.html">Change Password</a></li>
  <li><a href="apply_for_leave.html">Apply for leave</a></li>
  <li><a href="leave_history.php">Leave history</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>

<div class="pagewelcome"> 

<div class="pagewelcomeleft">
<center>

<h1>Welcome<h1><?php echo $_SESSION["username"]; ?>
<img src="39.png">
</center>
</div>
<div class="pagewelcomeright">
<center><h1>Profile</h1></center>
<p>
Name &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp&nbsp<?php echo $row['First_name']." ".$row['Last_name'] ?> <br>
Employee id &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp <?php echo $_SESSION['username'];?><br>
Department &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp <?php echo $row['Department'];?> <br>
Email id &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp <?php echo $row['Email'];?> <br>
Phone no. &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp <?php echo $row['Mobile_no'];?> <br>
Gender &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp <?php echo $row['Gender']?> <br>
Date of Birth &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <?php echo $row['DOB'];?> <br>

Leave Taken &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :&nbsp<?php echo $row['Leaves_taken'];?> <br>
</p>
</div>
</div>

</body>
</html>