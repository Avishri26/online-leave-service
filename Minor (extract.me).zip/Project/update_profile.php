<?php
	session_start();
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	
	
	$id = $_SESSION['username'];
	$result = mysql_query("Select * from employees where Employee_id= '$id' ");
	$row = mysql_fetch_array($result);
	
?>

<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "welcome.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
<title></title>
</head>
<body>

<header class="img">

<img src = "4.png" height = 100px align =left>
<h1>Online Leave Management System</h1>
</header>

<nav>
<ul>
 <li><a href="welcome.php">Dashboard</a></li>
  <li><a href="update_profile.php" class="active">Update Profile</a></li>
  <li><a href="change_password.html">Change Password</a></li>
  <li><a href="apply_for_leave.html">Apply for leave</a></li>
  <li><a href="leave_history.php">Leave history</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>

<div class="pageupdate"> 

<form method="POST"  action = "update_profile_change.php">
	<center>
	<span style = "font-size:30px;font-family: 'Montserrat', sans-serif;">Enter Details to Update</span><br><hr><br>
		<input readonly = "readonly" name = "fname" text value="<?php echo $row['First_name']?>"> &nbsp; &nbsp;
		<input readonly = "readonly" name = "lname" value="<?php echo $row['Last_name']?>" ><br><br>
		<input readonly = "readonly" name = "emp_id" value="<?php echo $row['Employee_id']?>" >&nbsp; &nbsp
		<input readonly = "readonly" name = "department" value="<?php echo $row['Department']?>" ><br><br>
		
		<input type = "email" name = "email"  value="<?php echo $row['Email']?>" >&nbsp; &nbsp
		<input type = "text" name = "mobile_no"  value="<?php echo $row['Mobile_no']?>" ><br><br>
		
	
		<br>
		<button>Update</button>&nbsp; &nbsp
		<br><br>
		


		
	</center>
	</form>
</div>

</body>
</html>