<?php

	session_start();
	$host="localhost";
	$user="root";
	$pass="";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	$id = $_SESSION['username'];
	
	$sd = $_POST['start_date'];
	$ed = $_POST['end_date'];
	$type = $_POST['leave_type'];
	$des = $_POST['description'];
	$status = "Pending";
	
	$leave = mysql_query("Select Leaves_taken from employees where Employee_id = '$id'");
	
	
	$row = mysql_fetch_array($leave);

	$count = $row['Leaves_taken'];

	$count = $count + 1;

	$result = mysql_query("Update employees Set Leaves_taken = '$count' where Employee_id = '$id'");
	if(mysql_affected_rows($con) == 1){
		
	
	
		$sql = "Insert into leaves(Employee_id,Start_date,End_date,Status,Type,Description) values('$id','$sd','$ed','$status','$type','$des')";
		if(mysql_query($sql)){
				echo "Leave applied successfuly";
				header("Refresh:3;url=apply_for_leave.html");
		}
		else{
			echo "Problem occured ";
			header("Refresh:3;url=apply_for_leave.html");
		}
	}
	else{
			echo "Problem occured";
	}
	
	
?>