<?php
session_start();
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db="college";
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	

	$id = $_SESSION['username'];
	//$result = mysql_query("Select * from employees where Employee_id= '$id' ");
	//$row = mysql_fetch_array($result);
	
	$email = $_POST['email'];
	$mobile = $_POST['mobile_no'];
	$update = mysql_query("UPDATE employees SET Email = '$email' ,Mobile_no = '$mobile' where Employee_id = '$id' ");
	if(mysql_affected_rows($con) == 1){
			header("Location:welcome.php");
	}
	else{
		echo "Error Occured";
		header("Refresh:3;url:update_profile.php");
	}	
?>