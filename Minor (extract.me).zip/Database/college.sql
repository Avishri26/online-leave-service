-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2019 at 02:47 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `First_name` varchar(20) NOT NULL,
  `Last_name` varchar(20) NOT NULL,
  `Employee_id` varchar(15) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Department` varchar(5) NOT NULL,
  `DOB` varchar(10) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Mobile_no` varchar(10) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `Leaves_taken` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`First_name`, `Last_name`, `Employee_id`, `Email`, `Department`, `DOB`, `Gender`, `Mobile_no`, `Password`, `Leaves_taken`) VALUES
('Admin', '', 'admin1620', 'admin1620@gmail.com', 'CSE', '', 'Male', '8989898989', 'AdminHOD@1620', 0),
('Faculty', '1', 'Faculty101', 'faculty1@gmail.com', 'CSE', '', 'Male', '8770267103', 'Faculty@1', 8),
('Faculty', '2', 'Faculty102', 'faculty2@gmail.com', 'CSE', '', 'Male', '8770267111', 'Faculty@2', 3),
('Faculty', '3', 'Faculty103', 'faculty3@gmail.com', 'CSE', '', 'Male', '8770267112', 'Faculty@3', 3);

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `Leave_id` int(10) NOT NULL,
  `Employee_id` varchar(20) NOT NULL,
  `Start_date` date NOT NULL,
  `End_date` date NOT NULL,
  `Status` varchar(15) NOT NULL,
  `Type` varchar(15) NOT NULL,
  `Description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`Leave_id`, `Employee_id`, `Start_date`, `End_date`, `Status`, `Type`, `Description`) VALUES
(2, 'Faculty101', '0000-00-00', '0000-00-00', 'Accept', 'Medical', ''),
(5, 'Faculty102', '0000-00-00', '0000-00-00', 'Accept', 'Funeral', ''),
(6, 'Faculty102', '0000-00-00', '0000-00-00', 'Decline', 'Medical', ''),
(7, 'Faculty103', '0000-00-00', '0000-00-00', 'Accept', 'Casual', ''),
(8, 'Faculty103', '0000-00-00', '0000-00-00', 'Decline', 'Funeral', ''),
(9, 'Faculty103', '0000-00-00', '0000-00-00', 'Accept', 'Vacation', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`Leave_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `Leave_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
